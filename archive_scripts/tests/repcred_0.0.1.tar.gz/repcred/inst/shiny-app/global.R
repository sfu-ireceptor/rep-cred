library(shiny)
library(repcred)
# Default file size limit is 5MB
# Increase max upload size per file to 50MB
options(shiny.maxRequestSize=50*1024^2)

