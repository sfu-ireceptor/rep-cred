Version 0.0.1: October 10, 2022
-------------------------------------------------------------------------------
+ Adapted package for CRAN submission